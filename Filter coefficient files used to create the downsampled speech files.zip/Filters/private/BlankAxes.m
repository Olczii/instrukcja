function nax = BlankAxes (ax)
% Create a new set of blank axes at the same position as the existing ones.
% The X and Y limits are set to the default values for a new set of axes.

% $Id: BlankAxes.m,v 1.8 2018/02/22 21:23:11 pkabal Exp $

if (nargin == 0)
   ax = gca;
end
nax = copyobj(ax, gcf);
delete(get(nax, 'Children'));

% No titles, labels or grid for the new axes
axes(nax);          % New axes on top
xlabel(nax, '');    % Explicit axis
ylabel(nax, '');
zlabel(nax, '');
title(nax, '');

% The new axes are on top, so we make the plot area transparent so the
% original plot shows through. The new axes handle visibility is set to off
% so that gca finds the old axes
% N.B., The new axes must remain on top; issuing axes(gca) brings the old
% axes to the top.
set(nax, 'Color', 'none');
set(nax, 'HandleVisibility', 'off');
set(nax, 'Visible', 'on');

set(nax, 'XTick', [], 'XTickLabel', []);
set(nax, 'YTick', [], 'YTickLabel', []);
set(nax, 'ZTick', [], 'ZTickLabel', []);

end

