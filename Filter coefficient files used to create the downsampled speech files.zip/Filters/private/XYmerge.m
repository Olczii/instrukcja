function [u,v] = XYmerge (x, y, EXY)
% Merge collinear plot vectors
% This routine compresses an array of plot vectors by merging collinear
% or near collinear vectors. The output vectors are subsets of the input
% vectors. The reduction in the number of vectors is useful in reducing the
% size of plot files.
%  x - vector of X coordinates
%  y - vector of Y coordinates
%  EXY - two element vector with the allowable error in X and Y allowed
%        when merging nearly collinear segments. If EXY is not explicitly
%        given, the default value take is as follows.
%        - if a plot exists and the plot limits have been set manually,
%          errors of 1/10 of a point (1/720 of an inch) are allowed. The
%          corresponding errors in data units are based on the current axis
%          limits and axis sizes.
%        - Otherwise, the maximum error is set to 1/2000 of the X and Y
%          extents, [max(x)-min(x), max(y)-min(y)]/2000.
%
% EXY not specified:
%   - Set the plot limits
%       axis([min(x) max(x) min(y) max(y)];
%       [xd, yd] = XYmerge(x, y);
%       plot(xd, yd);
%     Since XYmerge is normally called before plotting, the limit values
%     will have to be set manually as shown. 
%   - Call XYmerge with only two arguments. The maximum error allowed is
%     set to 1/10 of a point.
%   - Note that calling plot resets the limits, so the axis command may
%     have to be invoked again for full control of the axis values.
% Specify EXY:
%   - If the plot limits will be such that all data points fall within the
%     axes rectangle, set EXY as follows
%       EXY = [max(x)-min(x), max(y)-min(y)]/1000
%     In this example, the maximum allowable errors are 1/1000 of the plot
%     width/height.
%
% Notes:
% Log data:
%   This routine can be used to preprocess data which will be plotted on a
%   log scale.  One option is to set the axis limits and declare the plot
%   be on a log scale.
%     axis([plot limits>]);
%     set(gca, 'XScale', 'log');
%     set(gca, 'YScale', 'log');
%     [xd, yd] = XYmerge(x, y);     % Let XYmerge set EXY
%     loglog(xd, yd);
%   Another approach is to convert the input data to log values. The
%   error criterion EXY should be explicitly set to the tolerance in the 
%   log domain. The returned data can then be taken back to the linear
%   domain for plotting.
%     EXY = 0.001 * log10([max(x)-min(x), max(y)-min(y)]);
%     [Lxd, Lyd] = XYmerge(log10(x), log10(y), EXY);
%     xd = 10.^(Lxd);
%     yd = 10.^(Lyd);
%     loglog(xd, yd);      % Log plot
% Error criterion:
%   The algorithm works by processing 3 points at a time. Consider a line
%   joining the end points of the triplet. The length of the perpendicular
%   distance from the middle point to that line determines whether the
%   middle point can be omitted or not. The perpendicular distance has
%   components in both the X and Y directions, and as such, even for
%   equi-spaced data, some tolerance should be allowed on the X-error.

% $Id: XYmerge.m,v 1.23 2018/11/20 16:57:50 pkabal Exp $

% Algorithm:
%   The algorithm is greedy but short-sighted. When it hits a point at
%   which the error in the line exceeds the tolerance, it does not try to
%   extend the line beyond that point, when there may be a viable longer
%   line.

N = length(x);
if (N ~= length(y))
   error ('XYmerge: Unequal length vectors');
end

if (nargin < 3)
   [DataPt, XScale, YScale] = SFdataXpt();   % Data units per point
   if (~isempty(DataPt)  && (strcmp(get(gca, 'XLimMode'), 'manual') || ... 
                             strcmp(get(gca, 'YLimMode'), 'manual')))
      ExA = 0.1 * DataPt(1);        % For log scale, DataPt is log10(x)/pt
      EyA = 0.1 * DataPt(2);
   else
      XScale = 'linear';
      YScale = 'linear';
      ExA = (max(x) - min(x)) / 2000;
      EyA = (max(y) - min(y)) / 2000;
   end
else
   XScale = 'linear';
   YScale = 'linear';
   ExA = EXY(1);
   EyA = EXY(2);
end

% Work with column vectors, but set the final result to match the
% orientation of the input
xsize = size(x);
ysize = size(y);
x = x(:);
y = y(:);

LogX = strcmp(XScale, 'log');
LogY = strcmp(YScale, 'log');
if (LogX)
   x = log10(x);
end
if (LogY)
   y = log10(y);
end

B = 1;
k = 0;
k = k + 1;
kv(k) = B;
while (B <= N-1)
   
   % B - is a base point
   % G - is a known good point (the line from B to G can be approximated by
   %     a single line)
   % T - is a test point beyond G - we will test the line from B to T and
   %     reset G to T if we are successful.
   % Infinite or NaN values for B, G and/or T result in OK = 0
   
   G = B + 1;
   step = 1;
   straddle = 0;
   Lx = length(x);
   while (1)
      T = G + step;
      if (T > Lx)   % Don't look beyond the array
         straddle = 1;
         OK = 0;
      else
         
         % Main test loop (loop over B+1:T-1, permuted)
         % The indices are arranged from the middle out to abort the test
         % as quickly as possible - Tests indicate a 25% reduction in
         % evaluations of Test3 over a sequential search.
         I = B+1:T-1;
         Ni = length(I);
         II = reshape([I; fliplr(I)], 1, []);
         II = II(Ni+1:end);   % Search from middle out
         for (i = II)
            
            % Catch inflection points where the line changes from or to an
            % exact horizontal or an exact vertical
            OK = TestVH(x(B), y(B), x(i), y(i), x(T), y(T));
            
            if (isnan(OK))   % Not vertical or horizontal
               OK = Test3(x(B), y(B), x(i), y(i), x(T), y(T), ExA, EyA);
            end
            if (~ OK)
               straddle = 1;
               break
            end
         end
         
      end
      
      %  (1) If we have found a T which does not work, we know the end
      %      point is in the interval G:T-1. Use a binary search
      %      (decreasing the step size) to find the end point.
      %  (2) If we have not found a T which does not work, keep looking by
      %      increasing the step size.
      if (straddle)
         if (OK)
            G = T;
         end
         if (step == 1)
            break
         end
         step = step / 2;
         continue
      else    % success, but not straddling the end point
         G = T;
         step = 2 * step;
         continue
      end
   end
   
   B = G;
   k = k + 1;
   kv(k) = B;
end

if (LogX)
   u = 10.^x(kv);
else
   u = x(kv);
end
if (LogY)
   v = 10.^y(kv);
else
   v = y(kv);
end

% Set the orientation of u and v to match x and y
if (xsize(2) > xsize(1))
   u = u.';
end
if (ysize(2) > ysize(1))
   v = v.';
end
fprintf('XYmerge: No. points (in/out): %d/%d\n', N, k);

end

%==========
function OK = Test3 (x1, y1, x2, y2, x3, y3, ExA, EyA)
% OK is a flag, 1 means OK to skip the middle point
%               0 means we need to keep the middle point

% Consider 3 points.  Draw a straight line between the end points.
% The middle point will be skipped if the X and Y components of the
% perpendicular distance from the middle point to the straight line are
% smaller than given tolerances.
%
% The first step is to translate the axes so that (x(m),y(m)) becomes
% (0,0).
%               [x2,y2]                  [p1,q1]
%                  o                          o
%                 / \                        / \
%                /   \                      /   \
%               /     o                    /     o
%              /   [x3,y3]                /   [p2,q2]
%     [x1,y1] o                    [0,0] o

% A rotation about the origin through an angle w (CCW) can be expressed as
%   [r] = [cos(w) -sin(w)] [p]
%   [s]   [sin(w)  cos(w)] [q].
% The perpendicular error at (p1,q1) can be determined by a rotation about
% (0,0) such that the line from the (0,0) to (p2,q2) is horizontal. The
% rotation is through the angle -a, where
%   cos(a) = p2 / D,
%   sin(a) = q2 / D,
% and D = sqrt(p2^2 + q2^2).  The perpendicular error is the ordinate value
% of (p1,q1) after rotation,
%   errN = q1 cos(a) - p1 sin(a).
% The components of this error in the original X and Y directions can be
% found by projecting errN,
%   errX = sin(a) errN,
%   errY = -cos(a) errN.

% The test for the absolute X error is
%   |errX| > ExA.
% Or,
%   |sin(a) (q1 cos(a) - p1 sin(a))| > ExA
%
%    q2     p2      q2
%   |-- (q1 -- - p1 --)| > ExA
%    D      D       D
% or
%   |q2 (q1 p2 - p1 q2)| > D^2 ExA
% This rearrangement avoids possible divisions by zero.
%
% Similarly the check for the Y error is,
%   |p2 (q1 p2 - p1 q2)| > D^2 EyA

% The error region is a rectangle. It would be easy to change the error
% region to be an ellipse with the given errors as the axes.

% Any NaN in these expressions will result in OK = 0
p1 = x2 - x1;
q1 = y2 - y1;
p2 = x3 - x1;
q2 = y3 - y1;

D2 = p2^2 + q2^2;
err = q1 * p2 - p1 * q2;
OK = (abs(q2 * err) <= D2 * ExA) & (abs(p2 * err) <= D2 * EyA);

end

%==========
function OK = TestVH (x1, y1, x2, y2, x3, y3)
% OK - NaN, if neither segment is exactly vertical or exactly horizontal
%      1, if the first segment and the second segment are both vertical or
%         both horizontal
%      0, otherwise

% Test for vertical / horizontal
% 0 - neither
% 1 - exact vertical
% 2 - exact horizontal

% Test (x1, y1) to (x2, y2)
T12 = 0;
if (x1 == x2)
   T12 = 1;
elseif (y1 == y2)
   T12 = 2;
end

% Test (x2, y2) to (x3, y3)
T23 = 0;
if (x2 == x3)
   T23 = 1;
elseif (y2 == y3)
   T23 = 2;
end

if (T12 == 0 && T23 == 0)
   OK = NaN;
elseif (T12 == T23)
   OK = 1;
else
   OK = 0;
end

end
