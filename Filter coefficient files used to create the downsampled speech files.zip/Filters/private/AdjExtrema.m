function [x, Fx] = AdjExtrema(Fn, x)
% Adjust elements of a vector x so that the extrema of function Fn(x) are
% better represented. The elements of x which correspond to local extrema
% (minima and maxima) are located. These x values are modified to evaluate
% the function closer to the minimum or maximum. The change in the maxima
% and minima means that a plot of the modified data results in a better
% rendition of the envelope of the underlying function. The modified x
% values remain between the (original) adjacent x values.
%
% Fn(x) - Function handle. This function takes a variable number of x
%   values and returns the same number of function values. The call
%   Fx = Fn(x(1:N)) should return the same as Fx(1) = Fn(x(1)); ...
%   Fn(N) = Fx(x(N)). During execution, this function will be called
%   initially with all values of x, and then with a variable number of the
%   x values corresponding to extrema. This functon will be called with
%   x as a column vector.
% x - Initial vector. This vector will be converted to a column vector
%   before calling Fn.
%
% Output:
% x - The x values at the extema are updated; other values are unchanged.
% Fx - Function values at the x values
%
% Example: Sine with increasing frequency
%   Fn = @(x)(sin(2*pi*x.^2));   % Anonymous function
%   t0 = linspace(0, 4, 101);
%   [t1, Fx1] = AdjExtrema(Fn, t0);
%   plot(t1, Fx1);

% $Id: AdjExtrema.m,v 1.7 2018/11/22 16:59:00 pkabal Exp $

% Initial function values at the full x vector
Fx = Fn(x);

% Work with column vectors, restore the orientation on return
xsize = size(x);
x = x(:);
Fxsize = size(Fx);
Fx = Fx(:);

% Find the local maxima and minima - extrema have slopes of different signs
% on either side
Fxdiff = diff(Fx);
IExt = [false; (Fxdiff(1:end-1) .* Fxdiff(2:end) < 0); false];
if (~any(IExt))
  return;   % Quick exit for functions with no extrema
end
IMax = [0; (Fxdiff(1:end-1) > 0); 0] & IExt;
IMin = [0; (Fxdiff(1:end-1) < 0); 0] & IExt;

% Consistency check
if (~isequal(IExt, xor(IMax, IMin)))
  error('Extrema check failed');
end
IMaxExt = IMax(IExt);
IMinExt = IMin(IExt);

% Set up the step sizes
xdiff = diff(x);
dxu = 0.5 * [0; xdiff(1:end-1); 0];
dxd = 0.5 * [0; xdiff(2:end); 0];

% Subsets at the extrema
dxuExt = dxu(IExt);
dxdExt = dxd(IExt);
FxExt = Fx(IExt);
xExt = x(IExt);

% Modify the extrema points
[xExt, FxExt] = AdjExt(Fn, xExt, FxExt, IMaxExt, IMinExt, dxuExt, dxdExt);

% Put the new point into the full vectore
x(IExt) = xExt;
Fx(IExt) = FxExt;

% Reshape the vectors
if (xsize(2) > xsize(1))
  x = x.';
end
if (Fxsize(2) > Fxsize(1))
  Fx = Fx.';
end

end

% ----- ------
function [x, Fx] = AdjExt(Fn, x, Fx, IMax, IMin, dxu, dxd)
% Modify the points corresponding to local extrema, looking for a higher
% maximum or lower minimum.

% The underlying function in the interval being explored is assumed to be
% monotonic on either side of the peak or valley being sought.

% Number of evaluations: Assume symmetric function around the extremum. Let
% the number of extrema be N.
% Step up: Half of values will be in the wrong direction, and one half will
%   find a better extremal point.
%   - N evaluations, success rate about 25%
% Step down: approximately 0.75N evaluations
% Approximately 1.75N evaluations per iteration

NIter = 8;
for i = 1:NIter

  % Increment the evaluation points
  xt = x + dxu;
  Fxt = Fn(xt);

  % Find the points for which the modified frequencies give a better
  % rendition of the maxima or minima
  SU = (((Fxt > Fx) & IMax) | ((Fxt < Fx) & IMin));
  x(SU) = xt(SU);
  Fx(SU) = Fxt(SU);
% fprintf('Iter: %d, Succ. up:   %d / %d (%.1f %%)\n', ...
%         i, sum(SU), length(Fx), 100 * sum(SU)/length(Fx));

  % Initially, the step up and down may be different. As soon as we find
  % a better point, the rest of the updates will be only on one side of
  % initial point with the same up/down step sizes. The procedure after
  % the first success is effectively a binary search.
  dxd(SU) = dxu(SU);

  % Decrement the evalution points, but only those which were not
  % successful when probed upward
  xt = x - dxd;
  if (any(SU == 0))
    Fxt(~SU) = Fn(xt(~SU));
  end

  % For simplicity of code, the test involves all points, but only those
  % modified for the step down can result in a better result
  SD = (((Fxt > Fx) & IMax) | ((Fxt < Fx) & IMin));
  x(SD) = xt(SD);
  Fx(SD) = Fxt(SD);
% fprintf('         Succ. down: %d / %d (%.1f %%)\n', ...
%         sum(SD), length(Fx), 100*sum(SD)/length(Fx));
   
  dxu(SD) = dxd(SD);

  % Sanity check
  if (any(SU & SD))
    error('tXYAdjX: Consistency check failed');
  end
   
  % Halve the step size
  dxu = 0.5 * dxu;
  dxd = 0.5 * dxd;

end

end
