function h = MidTick (varargin)
% h = MidTick ([ax,] Axes [, options])
% Generate intermediate ticks on a plot axis.
% This function generates intermediate ticks between the existing X, Y, or
% Z axis ticks in a plot. For a linear axis, the intermediate ticks (0.75
% of the normal length) lie midway between the existing ticks. For a
% log axis, the ticks (0.5 of the normal length) lie at 1, 2, ..., 9 times
% the decade points. The intermediate ticks are unlabelled.
%
% The built in 'xMinorTick' plot option  often generatee too many minor
% ticks. For instance if the major ticks are 10 apart, the option may
% generate an additional 9 minor ticks. The present routine by default
% generates only one minor tick between major ticks, but arbitrary minor
% ticks can also be specified.
%
% The argument specifies the plot axes which get the mid-ticks. The axis
% argument is the concatenation of the axis designators 'X', 'Y', and/or
% 'Z'. If an axis designation appears in the axis argument, mid-ticks are
% placed on the correponding axis.
% (1) Specify the axes to have default X and Y mid-ticks.
%     h = MidTick('XY');
% (2) Specify the axes to have mid-ticks only for the Y axis.
%     h = MidTick('Y');
% (3) Override the intermediate ticks chosen by this routine. The routine
%     generates the default mid-ticks, the locations of which are then
%     overridden with a plot option.
%     h = MidTick('Y', 'YTick', [0.5, 1.5]);
%     
% The first argument is an an axes handle (gca by default). Additional
% trailing arguments can be used to specify other plot options, such as
% 'TickLength'.
%
% Note that Matlab generates minor ticks for log axes. The only reason
% to have this routine do so for log axes is for cases where some of the
% minor ticks are missing.
%
% A new transparent axis is generated on top of the existing axis. Note
% that  this new axis must remain on top for the newly generated ticks to
% be visible. The handle for this new axis is returned.
%  *** Invoke this routine after all plotting and labelling is done
%  *** It is suggested that the graph limits be set (using a call to
%      'axis()', for instance) before invoking this routine.

% $Id: MidTick.m,v 1.38 2018/10/26 02:28:39 pkabal Exp $

[ax, MTick, options] = Proc_Args(varargin{:});

% Generate the intermediate tick values
XTickm = Gen_Tickm(ax, MTick(1));
YTickm = Gen_Tickm(ax, MTick(2));
ZTickm = Gen_Tickm(ax, MTick(3));

% Freeze the limits on the old axes
% New axes - set TickLength
set(ax, 'XLimMode', 'manual');
set(ax, 'YLimMode', 'manual');
set(ax, 'ZLimMode', 'manual');
h = Set_TickmLength(ax);

% Set tick locations
Set_Tickm(h, XTickm, YTickm, ZTickm);

% Apply the rest of the arguments
if (~isempty(options))
   set(h, options{:});
end

end

%=========
function Tickm = Gen_Tickm (ax, Axis)

Tickm = [];

if (~ isnan(Axis))
   Lim = get(ax, [Axis 'Lim']);    % XLim or YLim or ZLim
   Tick = get(ax, [Axis 'Tick']);
   Scale = get(ax, [Axis 'Scale']);
   Tickm = Gen_Tick(Tick, Lim, Scale);
end

end

%==========
% Generate ticks midway between existing ticks, or log-spaced ticks
function htick = Gen_Tick (Tick, Lim, Scale)

NTick = length(Tick);
htick = [];

if (NTick > 1)
   if (strcmpi(Scale, 'linear'))
      htick = 0.5 * (Tick(1:NTick-1) + Tick(2:NTick));

      % See if we need to put some "mid-ticks" outside of the Tick values
      dTick = diff(Tick);
      dTickMax = max(dTick);
      dTickMin = min(dTick);
    
      % Check for near-constant interval lengths
      tol = 5 * eps * dTickMax;
      if (dTickMax - dTickMin < tol)
         htickL = Tick(1) - 0.5 * dTick(1);
         if (htickL >= Lim(1))
            htick = [htickL, htick];
         elseif (htickL > Lim(1) - tol)
            htick = [Lim(1), htick];
         end
         htickU = Tick(end) + 0.5 * dTick(end);
         if (htickU <= Lim(2))
            htick(end+1) = htickU;
         elseif (htickU < Lim(2) + tol)
            htick(end+1) = Lim(2);
         end
      end
  
   else
      LTick = floor(log10(Tick(1)))-1:ceil(log10(Tick(NTick)))+1;
      if (length(LTick) > 7)
         htick = [2 5]' * 10.^LTick;
      else
         htick = [2 3 4 5 6 7 8 9]' * 10.^LTick;
      end
      htick = (htick(:))';
      htick = htick(htick >= Lim(1) & htick <= Lim(2));
      htick(ismember(htick, Tick)) = [];  % Remove any arlready in Tick

   end
end

end

% ==========
function h = Set_TickmLength (ax)

% There is only one TickLength parameter for the plot
if (strcmpi(get(ax, 'XScale'), 'log') || ...
    strcmpi(get(ax, 'YScale'), 'log') || ...
    strcmpi(get(ax, 'ZScale'), 'log'))
    TickLengthm = 0.5 * get(ax, 'TickLength');
else
   TickLengthm = 0.75 * get(ax, 'TickLength');
end

% Put the mid-ticks into a new axis
h = BlankAxes(ax);
set(h, 'TickLength', TickLengthm);

end

% ==========
function Set_Tickm (h, XTickm, YTickm, ZTickm)

set(h, 'XTick', XTickm);
if (length(XTickm) > 1 )
   set(h, 'XMinorTick', 'off');
   set(gca, 'XminorTick', 'off');
end
set(h, 'YTick', YTickm);
if (length(YTickm) > 1)   
   set(h, 'YMinorTick', 'off');
   set(gca, 'YMinorTick', 'off');
end
set(h, 'ZTick', ZTickm);
if (length(ZTickm) > 1)
   set(h, 'ZMinorTick', 'off');
   set(gca, 'ZMinorTick', 'off');
end

end

%==========
% Process arguments, filling in defaults
function [ax, MTick, options] = Proc_Args (varargin)

if (length(varargin) < 1)
   error('MidTick - Too few input arguments');
end

% Axis, default to gca
ax = gca;
if (~ ischar(varargin{1}) && ishandle(varargin{1}))
   ax = varargin{1};
   varargin(1) = [];
end

% Decode the axis specification
MTick = MTick_Dec(varargin{1});
varargin(1) = [];

% Rest of the arguments
options = varargin;

end

% =========
function MTick = MTick_Dec (AxSpec)

AxTable = {'X', 'Y', 'Z'};
AxSpec = upper(AxSpec);

NAx = length(AxTable);
MTick = NaN(1, NAx);

for (i = 1:NAx)
   in = find(AxSpec == AxTable{i});
   if (~ isempty(in))
      AxSpec(in) = [];
      MTick(i) = AxTable{i};
   end
end

if (~ isempty(AxSpec))
   error('MidTick - Invalid axis specification');
end

end
