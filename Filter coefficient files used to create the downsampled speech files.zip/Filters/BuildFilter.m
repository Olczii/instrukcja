function BuildFilter()

% Build a composite filter for mIRSS filtering at 48 kHz, subsampled to
% to 8 kHz

% $Id: BuildFilter.m,v 1.3 2018/11/23 17:15:58 pkabal Exp $

% Convolve filters
FLPx3 = 'STL_LPx3_FIR.cof';
FmIRS = 'STL_mIRSS_FIR_16k.cof';
FLPx2 = 'STL_LPx2_FIR.cof';
FmIRS48k = 'STL_mIRSS_LPx6_FIR_48k.cof';

[b1, a1] = ReadFilter(FLPx3);
[b2, a2] = ReadFilter(FmIRS);
[b3, a3] = ReadFilter(FLPx2);

if (length(a1) ~= 1 || length(a2) ~= 1 || length(a3) ~= 1)
  error('Not an FIR filter');
end
b1 = b1 / a1(1);
b2 = b2 / a2(1);
b3 = b3 / a3(1);
Nb1 = length(b1);

% Strategy
% 1. Convolve 16 kHz filters
% 2. Force exact symmetry
% 3. Upsample the composite 16 kHz filter to 48 kHz
% 4. Convolve the 48 kHz filters
% 5. Force exact symmetry

% Convolve the 16 kHz filters, force symmetry
b23 = conv(b2, b3);
b23 = ForceSymmetry(b23);
Nb23 = length(b23);

% Upsample the composite 16 kHz filter
Ir = 3;
Nb23x = (Nb23 - 1) * Ir +1;
b23x = zeros(1, Nb23x);
b23x(1:Ir:Nb23x) = b23;

% Convolve the 48 kHz filters, force symmetry
bc = conv(b1, b23x);
bc = ForceSymmetry(bc);
Nb = length(bc);

assert(Nb == (Nb1 + Nb23x - 1));

% Write the composite filter coefficients to a file
% *** Negate the coefficients to get a positive main lobe ***
fid = fopen(FmIRS48k, 'w');
fprintf(fid, '!FIR - mIRSS filter for 48 kHz\n');
for i = 1:Nb
  fprintf(fid, '%.8g\n', -bc(i));
end
fclose(fid);

% Plot the response of the composite filter (read back from file)
[b, a] = ReadFilter(FmIRS48k);
if (length(a) ~= 1)
  error('Not an FIR filter');
end
PlotFilter(b, 1, [0,4500, 48000]);
xlabel('Frequency - Hz');
ylabel('Amplitude - dB');
title('Composite Filter Response');

end

% ----- -----
function b = ForceSymmetry(b)

% Symmetry factor
SymFactor = @(b) (sum(b .* fliplr(b)) / sum(b .* b));

Nb = length(b);

% Force exact symmetry
rho = SymFactor(b);
if (rho > 1 - 3e-16)
  % Assume the first half is more accurate
  Nh = floor(Nb/2);
  b(end:-1:Nb-Nh+1) = b(1:Nh);
  assert(SymFactor(b) == 1);
  fprintf('Force exact symmetry\n');
end

end
